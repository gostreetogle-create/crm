# Dictionaries CRUD Playbook

Цель: единый шаблон для добавления новых справочников в `/dictionaries` без расхождений с Demo и без дублирования логики.

Поведение полей и сценарии заполнения (create/edit/view/duplicate, placeholder, Excel): [`dictionary-field-behavior-guide.md`](./dictionary-field-behavior-guide.md).

## Канон (что обязательно)

1. Базовый экран справочников: `src/app/features/dictionaries/pages/dictionaries-page/`.
2. Визуальный эталон таблицы: блок `Универсальный CRUD` на `/demo`.
3. Для таблиц в справочниках используем `CrudLayout` в "чистом" режиме:
   - только `title + columns + data + actions`,
   - без `subtitle` и `facts` (если не согласовано отдельно).
4. Действия в строке — иконки, не текст (минимум: view/duplicate/edit/delete).
5. Excel-действия (`шаблон/импорт/экспорт`) подключаются через `CrudLayout` как единый стандарт для всех справочников.
6. Create/Edit/Delete/Duplicate доступны по ролям через `PermissionsService` + `*appHasPermission`.
7. Любая правка визуального/поведенческого CRUD-паттерна вносится сразу во все связанные блоки (`/demo` + `/dictionaries` + активные справочники), без частичных "точечных" фиксов.

## Архитектура новой фичи-справочника

Создавать по структуре:

- `src/app/features/<entity>/model/<entity>-item.ts`
- `src/app/features/<entity>/data/<entity>.repository.ts`
- `src/app/features/<entity>/data/<entity>.mock-repository.ts`
- `src/app/features/<entity>/state/<entity>.store.ts`

Подключение в `/dictionaries`:

- провайдеры в `src/app/app.routes.ts` внутри route `path: 'dictionaries'`,
- UI-блок в `dictionaries-page`:
  - таблица `CrudLayout`,
  - create-кнопка через встроенный API `CrudLayout` (`showCreateAction` + `(create)`),
  - модалка create/edit,
  - delete с confirm.

## Роли и права (обязательный минимум)

Права задаются только через:

- `src/app/core/auth/authz.types.ts`
- `src/app/core/auth/authz.matrix.ts`
- `src/app/core/auth/permissions.service.ts`

Для новой кнопки/действия:

1. Добавить проверку в шаблоне через входы `CrudLayout` (`canCreate`, `canEdit`, `canDelete`, и т.д.) или `*appHasPermission`.
2. Дублировать guard в методе TS через `permissions.can(...)`.

Нельзя делать отдельные страницы под роли, если меняется только доступ к действиям.

## UX-стандарт CRUD в `/dictionaries`

- Create/Edit: через `UiModal`.
- View: через `UiModal` в режиме read-only.
- Delete: только через подтверждение в `UiModal` (не нативный `window.confirm`).
- Excel в toolbar: через встроенные события `CrudLayout` (`downloadTemplate` / `importExcel` / `exportExcel`), без локальных кнопок.
- Поиск по названию в toolbar: встроенный в `CrudLayout`, располагается между create-кнопкой (`+`) и Excel-кнопками.
- Роли для Excel-кнопок: через `permissions.can('excel.template'|'excel.import'|'excel.export')`.
- Анти-хаос правило: Excel toolbar всегда подключается единообразно через `CrudLayout` во всех справочниках.
- Текущее состояние эталона: `showExcelActions=true` во всех карточках `/dictionaries`; права управляют видимостью отдельных кнопок.
- Жесткий gate: изменения в CRUD/Excel сначала отражаются в `/demo` (эталон), затем в `/dictionaries` в том же изменении.
- Нейминг (обязательно): все длинные/короткие наименования брать только из `docs/frontend/dictionaries-naming-convention.md`.
- Для справочника единиц измерения:
  - название карточки (длинное): `Единицы измерения`,
  - сокращение для полей/колонок: `Ед. изм.`.
- Для справочника отделки:
  - название карточки (длинное): `Тип отделки / шероховатость`,
  - сокращения для полей/колонок: `Тип отд.` и `Шерох.`.
- Для справочника цветов RAL:
  - поле/колонка названия всегда полное: `Название`,
  - в title модалки для режима вставки используем короткий тег после дефиса: `— Цвет`.
  - в create-форме поле `Код RAL` стартует с дефолтом `RAL ` для единообразия ввода.
- Для всех справочников в режиме просмотра (`View`) заголовок модалки строится в формате:
  - `Просмотр <длинное название> — <короткое название>`.
- Подписи: в колонках `CrudLayout` — короткие; в полях формы внутри `UiModal` (create/edit/view) — полные. Канон: `docs/frontend/dictionaries-naming-convention.md` (§4).
- Формы: Reactive Forms + `UiFormFieldComponent`/`UiCheckboxFieldComponent`.
- Плотность полей: compact-режим (уменьшенная высота полей, светлая линия границы).
- Если в форме больше 5 полей, прокрутка идет внутри модалки (контентная зона), без роста окна.
- Ошибки валидации: на русском, рядом с полем.
- Стили: только theme tokens, без локальных палитр.

## Чеклист перед merge

1. Сверить с `/demo` визуальный каркас таблицы.
2. Проверить роли:
   - `admin`: create/duplicate/edit/delete,
   - `editor`: create/duplicate/edit,
   - `viewer`: read-only.
3. Проверить, что в UI нет `subtitle`/`facts` в `CrudLayout` для нового справочника (если не согласовано).
4. Выполнить:
   - `nx build crm-web`
   - lint-check измененных файлов.
5. Обновить docs:
   - этот playbook при изменении общих правил,
   - feature-doc для нового справочника.
6. Подтвердить отсутствие "точечных" расхождений:
   - проверить все карточки справочников на единый паттерн,
   - если где-то синхронизация отложена, добавить явный checklist-долг (что, где, до какого этапа).

## Реестр manufacturing (предметная область)

Плановый реестр полей и статусов `exists`/`new`, расхождения с текущим UI (`domainVsUi`), нумерованный бэклог и шлюз согласования «пункт N» перед внедрением: [`справочники/README.md`](../../справочники/README.md) и JSON [`справочники/crm-manufacturing-dictionaries.json`](../../справочники/crm-manufacturing-dictionaries.json). Черновики до канона — в `справочники/tips/manufacturing/`.

## Реестр manufacturing (JSON)

Канонический реестр предметной области и правила папки `справочники/` (в т.ч. синхронизация `status` с UI): [`справочники/README.md`](../../справочники/README.md).
