﻿Пакет для комитета (manufacturing-справочники и канон документации)
Дата сборки: 2026-03-27
Репозиторий: crm (ветка main на момент упаковки)

Содержимое:
- справочники/ — реестр crm-manufacturing-dictionaries.json, README, tips/manufacturing (в т.ч. integration-followups-checklist.md)
- docs/ — business-logic-canon.md, README
- docs/frontend/ — чеклисты, playbook, feature-doc геометрий и видов работ, costing, naming convention

Исходный код crm-web в архив не входит (только артефакты согласования и процесса).
